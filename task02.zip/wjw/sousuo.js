$(document).ready(function(){

	$('.search-btn').click(function(){
		var str = $('.search-text').val();
		var ret = /^[\u4e00-\u9fa5]+$/ ;
      	if(ret.test(str)){
      		Show(str);
      	}else{
        	alert('请重新输入');
      	}
      	
	});
	var num = $('.searchBox-con td').length;
	var i=0;
	function Show(obj){
		if(i==num){
			i = 0;
		}
		$('.searchBox-con td').eq(i)
				.html(obj);
		i++;
	}	
	
})