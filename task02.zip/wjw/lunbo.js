// 	var container=document.getElementById('container');
// 	var list=document.getElementById('list');
// 	var buttons=document.getElementById('buttons').getElementsByTagName("span");
// 	var prev=document.getElementById('prev');
// 	var next=document.getElementById('next');
// 	var index=1;
// 	function showButton() {
// 		for (var i = 0; i <buttons.length; i++) {
// 			if (buttons[i].className=='on') {
// 				buttons[i].className='';
// 				break;
// 			}
// 		}
// 		buttons[index-1].className='on';
// 	}
// 	function animate(offset) {
// 		var newLeft=parseInt(list.style.left)+offset;
// 			list.style.left=newLeft+'px';
// 			if (newLeft>-1400) {
// 				list.style.left=-4200+'px';
// 				}
// 			if (newLeft<-4200) {
// 				list.style.left=-1400+'px';
// 			}	
// 	}
// 	next.onclick=function(){
// 		if (index==3) {
// 			index=1;
// 		}
// 		else{
// 			index +=1;
// 		}
// 		showButton();
// 		animate(-1400);
// 	}
// 	prev.onclick=function(){
// 		if (index==1) {
// 			index=3;
// 		}
// 		else{
// 			index -=1;
// 		}
// 		showButton();
// 		animate(+1400);
// 	}

// //自动轮播
//       function auto(){
//       	setInterval(function(){
//       		next.onclick();
//       	},3000)
//       }
//       auto();
// 	for (var i = 0; i <= buttons.length; i++) {
// 		buttons[i].onclick=function(){
// 			if (this.className=='on') {return;}
// 			var myIndex=parseInt(this.getAttribute('index'));
// 			var offset=-1400*(myIndex-index);
// 			animate(offset);
// 			index=myIndex;
// 			showButton();
// 		}
// 	}

// //搜索框验证
// 	
window.onload=function() {
	var container=document.getElementById('container');
	var list=document.getElementById('list');
	var buttons=document.getElementById('buttons').getElementsByTagName('span');
	var prev=document.getElementById('prev');
	var next=document.getElementById('next');
	var index=1;
	function showButton() {
		for (var i = 0; i <buttons.length; i++) {
			if (buttons[i].className=='on') {
				buttons[i].className='';
				break;
			}
		}
		buttons[index-1].className='on';
	}
	function animate(offset) {
		var newLeft=parseInt(list.style.left)+offset;
			list.style.left=newLeft+'px';
			if (newLeft>-1400) {
				list.style.left=-4200+'px';
				}
			if (newLeft<-4200) {
				list.style.left=-1400+'px';
			}	
	}
	next.onclick=function(){
		if (index==3) {
			index=1;
		}
		else{
			index +=1;
		}
		showButton();
		animate(-1400);
	}
	prev.onclick=function(){
		if (index==1) {
			index=3;
		}
		else{
			index -=1;
		}
		showButton();
		animate(+1400);
	}
	for (var i = 0; i <= buttons.length; i++) {
		buttons[i].onclick=function(){
			if (this.className=='on') {return;}
			var myIndex=parseInt(this.getAttribute('index'));
			var offset=-1400*(myIndex-index);
			animate(offset);
			index=myIndex;
			showButton();
		}
	}
}
//搜索框验证
	